'use strict';

var logos = false;
var score = 0;
var total = 0;
var intentos = 0;

var Intento = function()
{
    score = 0;
    intentos++;
    if(intentos >= 2)
      $(".regresar-button").hide();
}

var HYPEReady = function() 
{    
    var tema = 1;
    
    $(".next-videobutton").hide();
    $(".back-videobutton").hide();
    /*var offset = $(".barra").offset();
        var originLeft = offset.left;
        var originTop = offset.top;
        $( ".barra" ).animate({
            top:'8000px'
  }, 1000, function() {
    // Animation complete.
  });*/
    $('video').on('ended',function(){
      $(".next-videobutton").show();
        $(".back-videobutton").show();
    });
    /*var crearTitulo = function () {
        $(document.createElement("div")).addClass("titulo")
        .css({
            "background": "#0089AB",
            "background-image": "url('general/flecha.png')",
            "background-repeat": "no-repeat",
            "background-position": "center",
            "padding": "5px",
            "width": "50px",
            "height": "55px",
            "position": "absolute",
            "right": "0px",
            "top": "74px",
            "cursor": "pointer",
            "color": "#fff",
            "text-align": "center",
            "z-index":"99",
            "border-top-left-radius":"10px",
            "border-bottom-left-radius":"10px",
        }).text(".").appendTo(".HYPE_scene");
    };

    var crearTema = function() {

        var $currentScene = $(".HYPE_scene").filter(function() {
            return $(this).css("display") == "block";
          });

        if(!$currentScene.find(".contenido")[0]) {

            $(document.createElement("div")).addClass("contenido")
            .css({
                "background":"#0089AB",
                "padding":"20px 10px",
                "display": "none",
                "position": "relative",
                "top": "40px",
                "right": "-5px",
                "text-align": "right",
                "float": "right",
                "z-index":"99",
                "border-radius":"10px",
                "text-align": "left",
                }).append("<label><b>TEMA: TOTUS TEMA 1 ALGO QUE HACER.</b><br><br>TITULO: TITULO 1</label>").appendTo(".HYPE_scene .titulo");
            };
        };


    crearTitulo();
    crearTema();

    //SCRIPT CREADO PARA GENERAR UN LOGO EN DETERMINADA POSICION
    /*
    var createlogo = function() {
          if(!logos) {
            var $logo = $("div").filter(function() {
              return $(this).css("backgroundImage").match(/logo%20asf.png/ig) || $(this).css("backgroundImage").match(/Microsoft_Excel_2013_logo.png/ig);
            });
            $logo.hide();
             logos = true;
          }

          var $currentScene = $(".HYPE_scene").filter(function() {
            return $(this).css("display") == "block";
          });

          if(!$currentScene.find(".main-logo")[0]) {
            $(document.createElement("div"))
             .addClass("main-logo")
             .css({
               "pointer-events": "auto",
               "position": "absolute",
               "border": "0",
               "overflow": "visible",
               "z-index": "99",
               "width": "254px",
               "height": "91px",
               "top": "0",
               "left": "768px",
             }).appendTo(".HYPE_scene");
         }
    };
    createlogo();

    */


    /*SCRIPT PARA OCULTAR Y MOSTRAR EL CUADRO DE TITULO*/
    $(".titulo").click(function () {

        tema = viewTitle();

        //limpio el div
        $(".contenido").text(" ");

        //Agrego la informacion
        
        $(".contenido").append("<label><b>" + tema + ".</label>");

        //muestro el div
        $(".contenido").slideToggle("slow");
    });

    /**
     * [isPlaying description]
     * @return {void}
     */
    var isPlaying = function () {

        $(".play-pause").removeClass("playing").removeClass("ended");
        var interval = window.setInterval(function() {

            if(parent.$hype.isPlayingTimelineNamed()) {

                if(!$(".play-pause").hasClass("playing"))
                    $(".play-pause").addClass("playing")

            } else {

                $(".play-pause").removeClass("playing").addClass("ended");
                window.clearInterval(interval);
            }
        }, 250);
    };
    
    
        

    /**
     * [function description]
     * @return {void}
     */
    var setNavigation = function() {

        $(".boton-fin-curso")
            .off("click").on("click", function() {
                console.log("entra fin curso");
                window.top.close();
            })
            .off("mouseover").on("mouseover", mouseOverButton)
            .off("mouseout").on("mouseout", mouseOutButton);
        
        $(".play-pause")
            .off("click").on("click", function() {
                toogleTimeline();
            })
            .off("mouseover").on("mouseover", mouseOverButton)
            .off("mouseout").on("mouseout", mouseOutButton);

        $(".back-button")
            .off("click").on("click", prevButtonClick)
            .off("mouseover").on("mouseover", mouseOverButton)
            .off("mouseout").on("mouseout", mouseOutButton);

        $(".next-button")
            .off("click").on("click", nextButtonClick)
            .off("mouseover").on("mouseover", mouseOverButton)
            .off("mouseout").on("mouseout", mouseOutButton);

        $(".sound-mute")
            .off("click").on("click", toggleSound)
            .off("mouseover").on("mouseover", mouseOverButton)
            .off("mouseout").on("mouseout", mouseOutButton);

        $(".index-button")
            .off("click").on("click", toggleIndex)
            .off("mouseover").on("mouseover", mouseOverButton)
            .off("mouseout").on("mouseout", mouseOutButton);
        
        $('div .1t1').off('click').on('click', function(){
               score++;
               console.log(score);
         }).off("mouseover").on("mouseover", mouseOverButton)
            .off("mouseout").on("mouseout", mouseOutButton);
        
        $('div .2t2').off('click').on('click', function(){
             score++;
               console.log(score);
         }).off("mouseover").on("mouseover", mouseOverButton)
            .off("mouseout").on("mouseout", mouseOutButton);
        
        $('div .3t1').off('click').on('click', function(){
               score++;
               console.log(score);
         }).off("mouseover").on("mouseover", mouseOverButton)
            .off("mouseout").on("mouseout", mouseOutButton);
        
        $('div .4t4').off('click').on('click', function(){
             score++;
               console.log(score);
         }).off("mouseover").on("mouseover", mouseOverButton)
            .off("mouseout").on("mouseout", mouseOutButton);
        
        $('div .5t1').off('click').on('click', function(){
            score++;
               console.log(score);
         }).off("mouseover").on("mouseover", mouseOverButton)
            .off("mouseout").on("mouseout", mouseOutButton);
        
        $('div .6t1').off('click').on('click', function(){
               comprobar();
               console.log(score);
         }).off("mouseover").on("mouseover", mouseOverButton)
            .off("mouseout").on("mouseout", mouseOutButton);
        
        $('div .6t2').off('click').on('click', function(){
              score++;
              comprobar();
               console.log(score);
         }).off("mouseover").on("mouseover", mouseOverButton)
            .off("mouseout").on("mouseout", mouseOutButton);
          $('div .6t3').off('click').on('click', function(){
              comprobar();
               console.log(score);
         }).off("mouseover").on("mouseover", mouseOverButton)
            .off("mouseout").on("mouseout", mouseOutButton);
    };
    
   /*var comprobar = function(){
    
		total = (score * 100)/6;
       total = Math.round(total)    //redondear a 0 decimales
        console.log(total);
		if(parent.lmsConnected) {
			console.log("Connected");
			parent.scorm.set("cmi.core.score.min", 0);
			parent.scorm.set("cmi.core.score.max", 100);
			parent.scorm.set("cmi.core.score.raw", total);

			if(total >= 80)
				parent.scorm.set("cmi.core.lesson_status", "completed");
			/*else
				parent.scorm.set("cmi.core.lesson_status", "failed");*/

			/*parent.scorm.save();
		}

		if(score >= 4 ){
            $("div .total").text(total + "%");
			parent.$hype.showSceneNamed("Si");
            $("div .total").text(total + "%");
        }
		else{
            $("div .total").text(total + "%");
			parent.$hype.showSceneNamed("No");
            $("div .total").text(total + "%");
        }

	};*/
    
    
    
    /**
     * [function description]
     * @param  {boolean} forced [description]
     * @return {void}
     */
    var toogleTimeline = function(forced) {

        if(parent.$hype.isPlayingTimelineNamed() || forced) {

            parent.$hype.pauseTimelineNamed();

            var audios = document.getElementsByTagName("audio");
            for( var audio in audios) {

                if(typeof audios[audio].volume !== "undefined") {
                    audios[audio].pause();
                    audios[audio].currentTime = 0;
                }
            }
        } else {

            parent.$hype.startTimelineNamed();
            parent.$hype.relayoutIfNecessary();
            isPlaying();
        }
    };

    /**
     * [function description]
     * @return {void}
     */
    var nextButtonClick = function() {

        console.log("algo")
        
        // Necesario verificar si la escena
        // no se encuentra en ejecución
       if(! parent.$hype.isPlayingTimelineNamed() && ! $(this).hasClass("button-off")) {

            console.log("entrando")

            parent.showLoader();

            var sceneNames = parent.$hype.sceneNames() || []; // hypeDocument.sceneNames: ["master"]
            var lastScene = sceneNames[sceneNames.length - 1];
                        // Hay que checar si se encuentra en la última escena
            // en caso contrario, ejecutar la función de hype
            // para avanzar de escena
            if(lastScene == parent.$hype.currentSceneName()) {

                var n = parent.getCurrentDocumentIndex();
                var newDoc = parent.setNewDocument("S" + (n + 1));
                parent.renderDocument(n + 1);

            // Sería bueno verificar que no carezca de escenas
            } else if(sceneNames[0] != null) {

                // Primero detenemos todo
                toogleTimeline(true);
                // Ahora sí... la función por default de hype
                parent.$hype.showNextScene(parent.$hype.kSceneTransitionCrossfade, 1.1);
            }
        }
    };

    /**
     * [function description]
     * @return {void}
     */
    var prevButtonClick = function() {

        if(! $(this).hasClass("button-off")) {

            parent.showLoader();

            var sceneNames = parent.$hype.sceneNames() || []; // hypeDocument.sceneNames: ["master"]
            var firstScene = sceneNames[0];

            // Hay que checar si no se encuentra en la primer escena
            // en caso contrario, ejecutar la función de hype
            // para retroceder de escena
            if(firstScene == parent.$hype.currentSceneName()) {

                var n = parent.getCurrentDocumentIndex();
                if(n > 1) {

                    var newDoc = parent.setNewDocument("S" + (n - 1));
                    parent.renderDocument(n - 1);
                }

            // Sería bueno verificar que no carezca de escenas
            } else if(sceneNames[0] != null) {

                // Primero detenemos todo
                toogleTimeline(true);
                // Ahora sí... la función por default de hype
                parent.$hype.showPreviousScene(parent.$hype.kSceneTransitionCrossfade, 1.1);
            }
        }
    };

    /**
     * [function description]
     * @return {void}
     */
    var gotoSequence = function() {

        var sequence = $(this).attr("data-href").replace(".html", "");
        var index = Number(sequence.replace("S", ""));
        var last_location = parent.getLastLocationSCO() || {sequence: "S1"};
            last_location = Number(last_location.sequence.replace("S",""));

        if(! $(this).hasClass("button-off") ) {
            //&& index < last_location) {

            toogleTimeline(true);
            parent.showLoader();
            parent.setNewDocument(sequence);
            parent.renderDocument(index);
        }
    };

    /**
     * [function description]
     * @return {void}
     */
    var toggleSound = function() {

        var audios = document.getElementsByTagName("audio");
        for( var audio in audios) {

            if(typeof audios[audio].volume !== "undefined")
                audios[audio].volume = ! audios[audio].volume;
        }

        if(audios[0].volume == 0) $(this).addClass("muted");
        else $(this).removeClass("muted");
    };

    var isActiveScene = function(scene) { return $(".HYPE_scene[hype_scene_index="+scene+"]").css("display") != "none"; };
    var mouseOutButton = function(el) { $(this).removeClass("hovering"); };
    var mouseOverButton = function(el) { $(this).addClass("hovering"); };


    var startScrollingLeft = function() {
        // contintually increase scroll position
        $(".index-table ul").animate({scrollLeft: '-=100'}, startScrollingLeft);
    }

    var startScrollingRight = function() {
        // contintually increase scroll position
        $(".index-table ul").animate({scrollLeft: '+=100'}, startScrollingRight);
    }

    var stopScrolling = function() {
        // stop increasing scroll position
        $(".index-table ul").stop();
    }


    /* CREAR EL TEMA EN CADA ESCENA */
    var viewTitle = function () {

        var nombreSecuencia = parent.$hype.documentName();
        console.log(nombreSecuencia);
        var nSecuencia = nombreSecuencia.substring(1, nombreSecuencia.length);
        console.log("Numero de secuencia --> " + nSecuencia[0]);
        console.log(parent.index_table[nSecuencia-1].name);
        return parent.index_table[nSecuencia-1].name;
        
    }

    /**
     * [function description]
     * @return {void}
     */
    var createIndex = function() {

        var current_location = parent.getCurrentDocumentIndex();
        var last_location = parent.getLastLocationSCO() || {sequence: "S1"};
            last_location = Number(last_location.sequence.replace("S",""));

        var $index_table = $(document.createElement('div')).addClass("index-table").hide().appendTo("body");
        $(".index-table").append($(document.createElement('div')).addClass("index-title").text("Temario"));
        $(".index-table").append($(document.createElement('ul')));
        //$(".index-table").append($(document.createElement('div')).addClass('logo'));
        //$(".index-table").append($(document.createElement('svg')).addClass('logo-back'));
        $(".index-table").append($(document.createElement('div')).addClass('cerrar-button').on('click',function(){$index_table.hide()}));

        $(".index-table").append($(document.createElement('div')).addClass('left-button').mousedown(startScrollingLeft).mouseup(stopScrolling));
        $(".index-table").append($(document.createElement('div')).addClass('right-button').mousedown(startScrollingRight).mouseup(stopScrolling));

        $(".index-table")
            .append(
                $(document.createElement('div'))
                    .text('Da click en cerrar para continuar')
                    .addClass('cerrar-text')
                    .on('click',function(){
                        toggleIndex();
                    })
                );

        for(var i in parent.index_table) {
            
            //console.log(Number(last_location) , (Number(i)+1), Number(last_location) > (Number(i)+1))
            $(".index-table ul")
                .append(
                    $(document.createElement('li'))
                        .append(
                            $(document.createElement('a'))
                                .text(parent.index_table[i].name)
                                .attr("data-href", parent.index_table[i].href)
                                .addClass(last_location > (Number(i)+1) ? "viewed": "")
                                .addClass(current_location == (Number(i)+1) ? "current": "")
                                .on("click", gotoSequence)
                        )
                );
        }
    };

    /**
     * [function description]
     * @return {void}
     */
    var toggleIndex = function() {

        //toogleTimeline();

        if( ! $(".index-table").length) {

            createIndex();
            $(".index-table").show();
        } else {
            $(".index-table").toggle();
        }
    };

    parent.$hype = HYPE.documents[parent.getCurrentDocument()];

    // ··················································································································································
    // ·························· INIT ··················································································································
    // ··················································································································································
    // ··················································································································································

    // ---------------------
    // SETTINGS
    parent.saveLocation();
    parent.hideLoader();
    setNavigation();
    isPlaying();

   /*var sequenceScript = [ "S1" ];

    if(!parent.scripted || $.inArray(parent.getCurrentDocument(), sequenceScript) != -1) {

        parent.promises = {
            sequence: $.getScript("general/"+ parent.getCurrentDocument() +".js"),
            _index: $.ajax({
                contentType: "application/xml",
                cache: false,
                url: 'temario.xml', // name of file you want to parse
                dataType: "xml"
            })
        };

        // ---------------------
        // SCRIPTS PER SCENE

        parent.promises.sequence.always(function() {
            parent.scripted = true;

            if (typeof scriptsReady === "function") {
                scriptsReady();
            }
        });

        // ---------------------
        // XML
        parent.promises._index.done(function(data) {

            var $xml = $( data );
            parent.index_table = [];

            $xml.find("resources resource").each(function(k,v) {
                var data = {
                    href: $(v).attr("href"),
                    name: $(v).find("name").text()
                }
                //if(data.name != "Evaluación") {
                    parent.index_table.push(data);
                //}
            });
        });
    }*/
};
