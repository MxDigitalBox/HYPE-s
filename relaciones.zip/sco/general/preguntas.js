var HYPEReady = function() {
    parent.$hype = HYPE.documents[parent.getCurrentDocument()];
	var bien = -1;
	var numeroP = 0;
	var score = 0;
    var preguntasYa = [20,20,20];
    var preguntaContestada = false;
    
    $(".no").hide();//tache y mensaje de incorrecto oculto por default
    $(".si").hide();//paloma y mensasje de correcto oculto por default
    $(".comprobar").hide();//
    $(".finalMessgae").hide();//
	console.log("preguntas listas");	
	var preguntas = [
	     {      pregunta:"¿Qué hace la Dirección de Relaciones Exteriores?",  
	            0:"Ejecutar estrategias de vinculación nacional.-1", 
	            1:"Vincular al Grupo de forma nacional e internacional.-0",
                2:"Las dos anteriores.-0"
	     }, 
	     {      pregunta:"¿Con qué otro nombre se conoce a la Dirección de Relaciones Exteriores?", 
	            0:"Relaciones Exteriores-0", 
                1:"Direx-1", 
                2:"La Dirección-0"
	     },
	     {      pregunta:"¿En cuántos ejes se basan las estrategias de Direx?", 
                0:"3-0", 
                1:"4-0",
                2:"5-1"
	     }
	];
			
	//Nump es el numero de pregunta
	function CreaPregunta(nump, forma){
        console.log("Generando preguntas");
		console.log(nump + "--" + forma);
        parent.hideLoader();    
		$('div .pregunta').text(preguntas[nump]["pregunta"]);
		//Obtengo las respuestas
		var res1 = preguntas[nump][0].split('-');
		var res2 = preguntas[nump][1].split('-');
		var res3 = preguntas[nump][2].split('-');
        console.log("Que  hay aqui " + forma);
		//Creo las respuestas
		switch(forma)
		{   case 0:
				$('div .respuesta1').text(res1[0]).data("respuesta", "correcta");
				$('div .respuesta2').text(res2[0]).data("respuesta", "incorrecta");
				$('div .respuesta3').text(res3[0]).data("respuesta", "incorrecta");
				break;
			case 1:
				$('div .respuesta1').text(res1[0]).data("respuesta", "incorrecta");
				$('div .respuesta2').text(res2[0]).data("respuesta", "correcta");
				$('div .respuesta3').text(res3[0]).data("respuesta", "incorrecta");
				break;
			case 2:
				$('div .respuesta1').text(res1[0]).data("respuesta", "incorrecta");
				$('div .respuesta2').text(res2[0]).data("respuesta", "incorrecta");
				$('div .respuesta3').text(res3[0]).data("respuesta", "correcta");
				break;
		}
	}
    
var inP = Math.floor(Math.random() * 3);
    console.log("NPregunta --> " + inP);
    preguntasYa[numeroP] = inP;
	CreaPregunta(inP, inP);
    
    $('div .guardar-button').on('click', function(){
        console.log("entra fin curso");
                window.top.close();
	});

	$('div .respuestaBT1').on('click', function(){
        if(preguntaContestada)
            return;
        preguntaContestada = true;
		//verifico la respuesta correcta
		var preg = $('div .respuesta1').data("respuesta");
		if(preg== "correcta"){
			score++;
            $(".si").show();
		}else{
            $(".no").show();
        }
        
		numeroP++;
		$(".comprobar").show();
		if(numeroP == 3){
            //$(".mensajinContinuar").html("Da clic para <br>finalizar");
            console.log("Final");
        }else{
            //$(".mensajinContinuar").html("Da clic para <br>continuar");
            console.log("aun no");
        }
        $(".finalMessgae").show(); 
        console.log("Numero de pregunta: "+numeroP + " Score --> " + score);
	});

	$('div .respuestaBT2').on('click', function() {
        if(preguntaContestada)
            return;
        preguntaContestada = true;
		//verifico la respuesta correcta
		var preg = $('div .respuesta2').data("respuesta");
		if(preg== "correcta"){
			score++;  
            $(".si").show();
		}else{
            $(".no").show();
        }
      
		numeroP++;
		$(".comprobar").show();
		if(numeroP == 3){
            console.log("Final");
        }else{
            console.log("aun no");
            //$(".mensajinContinuar").html("Da clic para <br>continuar");
        }
        $(".finalMessgae").show();
        console.log("Numero de pregunta: "+numeroP + " Score --> " + score);
	});

	$('div .respuestaBT3').on('click', function()  {
        if(preguntaContestada)
            return;
        preguntaContestada = true;
		//verifico la respuesta correcta
		var preg = $('div .respuesta3').data("respuesta");
		if(preg== "correcta"){
			score++;
            $(".si").show();
		}else{
            $(".no").show();
        }
        
		numeroP++;
		$(".comprobar").show();
		if(numeroP == 3){
            //$(".mensajinContinuar").html("Da clic para <br>finalizar");
             console.log("Final");
        }else{
            //$(".mensajinContinuar").html("Da clic para <br>continuar");
            console.log("aun no");
        }
        $(".finalMessgae").show();
        console.log("Numero de pregunta: "+numeroP + " Score --> " + score);
	});

	$('div .comprobar').off('click').on('click', function(){ 
        if(numeroP == 3){
            console.log("calificacion");
            var total = 0;
            switch (score) {
                case 1:
                    total = 33;
                    break; 
                case 2:
                    total = 66;
                    break; 
                case 3: 
                    total = 100;
                    break;
                default: 0;
                    
            }
            if(parent.lmsConnected) {
                console.log("Connected");
                parent.scorm.set("cmi.core.score.min", 0);
                parent.scorm.set("cmi.core.score.max", 100);
                parent.scorm.set("cmi.core.score.raw", total);
                setTime(); 
                if(total == 80){
                    console.log("sacaste 80");
                    parent.scorm.set("cmi.core.lesson_status", "completed");
                } 
                if(total == 100){
                    console.log("sacaste 100");
                    parent.scorm.set("cmi.core.lesson_status", "passed"); 
                } 
                if(total < 80){
                    console.log("reprobaste");
                    parent.scorm.set("cmi.core.lesson_status", "failed");
                }
                parent.scorm.save();
            }
            parent.$hype = HYPE.documents[parent.getCurrentDocument()];
           
            parent.$hype.showSceneNamed("08_cortinilla_final");
            
        }
		else{
            preguntaContestada = false;
			console.log("Scrore --> " + score);
            var inPP = RegresaNP();
            console.log("NPregunta --> " + inPP);                      
            preguntasYa[numeroP] = inPP;
			CreaPregunta(inPP, inPP);
            //$(".comprobar").hide();
            //$(".finalMessgae").hide();
		}
        $(".comprobar").hide();
        $(".no").hide();
        $(".si").hide();
	});

    function RegresaNP(){
        var pasa = false;
        while(pasa == false){
                var np = Math.floor(Math.random() * 3);
                if(np != preguntasYa[0] && np != preguntasYa[1] && np != preguntasYa[2])
                    pasa = true;
            }
        return np;
    }
    
    //JCMV metodo que calcula e inserta el valor de SESSION_TIME al scrom
    function setTime(){
        var Que = $.cookie("objeto");
        console.log("Que es esto: " + Que);
        var timeNow = new Date();
        var n = timeNow.getTime() - Que;
        var v = MillisecondsToCMIDuration(n);//convert to SCORM time
        console.log("Valor!!!!!!! " + v);
        parent.scorm.set("cmi.core.total_time",v);
        parent.scorm.set("cmi.core.session_time",v);
    }

    //JCMV metodo que convierte la diferencia a minutos, segundos y milisegundos
    function MillisecondsToCMIDuration(n){
        //Convert duration from milliseconds to 0000:00:00.00 format
        var hms = "";
        var dtm = new Date();         
        dtm.setTime(n);
        var h = "000" + Math.floor(n / 3600000);
        var m = "0" + dtm.getMinutes();
        var s = "0" + dtm.getSeconds();
        var cs = "0" + Math.round(dtm.getMilliseconds() / 10);
        hms = h.substr(h.length-4)+":"+m.substr(m.length-2)+":";
        hms += s.substr(s.length-2)+"."+cs.substr(cs.length-2);
        return hms;
    }
    
	function Finalizar()
	{
		$('div .pregunta').text("Da clic en siguiente para finalizar");  
	}

};