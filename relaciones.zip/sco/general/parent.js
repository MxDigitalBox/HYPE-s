'use strict';

/* ===========================================================
pipwerks SCORM Wrapper for JavaScript
v1.1.20141226

Created by Philip Hutchison, January 2008-2014
https://github.com/pipwerks/scorm-api-wrapper

Copyright (c) Philip Hutchison
MIT-style license: http://pipwerks.mit-license.org/

This wrapper works with both SCORM 1.2 and SCORM 2004.

Inspired by APIWrapper.js, created by the ADL and
Concurrent Technologies Corporation, distributed by
the ADL (http://www.adlnet.gov/scorm).

SCORM.API.find() and SCORM.API.get() functions based
on ADL code, modified by Mike Rustici
(http://www.scorm.com/resources/apifinder/SCORMAPIFinder.htm),
further modified by Philip Hutchison
=============================================================== */
var pipwerks={};pipwerks.UTILS={},pipwerks.debug={isActive:!0},pipwerks.SCORM={version:null,handleCompletionStatus:!0,handleExitMode:!0,API:{handle:null,isFound:!1},connection:{isActive:!1},data:{completionStatus:null,exitStatus:null},debug:{}},pipwerks.SCORM.isAvailable=function(){return!0},pipwerks.SCORM.API.find=function(e){for(var i=null,t=0,n=500,s="SCORM.API.find",r=pipwerks.UTILS.trace,a=pipwerks.SCORM;!e.API&&!e.API_1484_11&&e.parent&&e.parent!=e&&n>=t;)t++,e=e.parent;if(a.version)switch(a.version){case"2004":e.API_1484_11?i=e.API_1484_11:r(s+": SCORM version 2004 was specified by user, but API_1484_11 cannot be found.");break;case"1.2":e.API?i=e.API:r(s+": SCORM version 1.2 was specified by user, but API cannot be found.")}else e.API_1484_11?(a.version="2004",i=e.API_1484_11):e.API&&(a.version="1.2",i=e.API);return i?(r(s+": API found. Version: "+a.version),r("API: "+i)):r(s+": Error finding API. \nFind attempts: "+t+". \nFind attempt limit: "+n),i},pipwerks.SCORM.API.get=function(){var e=null,i=window,t=pipwerks.SCORM,n=t.API.find,s=pipwerks.UTILS.trace;return e=n(i),!e&&i.parent&&i.parent!=i&&(e=n(i.parent)),!e&&i.top&&i.top.opener&&(e=n(i.top.opener)),
    !e&&i.top.opener&&i.top.opener.document&&(e=n(i.top.opener.document)),e?t.API.isFound=!0:s("API.get failed: Can't find the API!"),e},pipwerks.SCORM.API.getHandle=function(){var e=pipwerks.SCORM.API;return e.handle||e.isFound||(e.handle=e.get()),e.handle},pipwerks.SCORM.connection.initialize=function(){var e=!1,i=pipwerks.SCORM,t=i.data.completionStatus,n=pipwerks.UTILS.trace,s=pipwerks.UTILS.StringToBoolean,r=i.debug,a="SCORM.connection.initialize ";if(n("connection.initialize called."),i.connection.isActive)n(a+"aborted: Connection already active.");else{var o=i.API.getHandle(),c=0;if(o){switch(i.version){case"1.2":e=s(o.LMSInitialize(""));break;case"2004":e=s(o.Initialize(""))}if(e)if(c=r.getCode(),null!==c&&0===c){if(i.connection.isActive=!0,i.handleCompletionStatus&&(t=i.status("get"))){switch(t){case"not attempted":i.status("set","incomplete");break;case"unknown":i.status("set","incomplete")}i.save()}}else e=!1,n(a+"failed. \nError code: "+c+" \nError info: "+r.getInfo(c));else c=r.getCode(),n(null!==c&&0!==c?a+"failed. \nError code: "+c+" \nError info: "+r.getInfo(c):a+"failed: No response from server.")}else n(a+"failed: API is null.")}return e},
    pipwerks.SCORM.connection.terminate=function(){var e=!1,i=pipwerks.SCORM,t=i.data.exitStatus,n=i.data.completionStatus,s=pipwerks.UTILS.trace,r=pipwerks.UTILS.StringToBoolean,a=i.debug,o="SCORM.connection.terminate ";if(i.connection.isActive){var c=i.API.getHandle(),p=0;if(c){if(i.handleExitMode&&!t)if("completed"!==n&&"passed"!==n)switch(i.version){case"1.2":e=i.set("cmi.core.exit","suspend");break;case"2004":e=i.set("cmi.exit","suspend")}else switch(i.version){case"1.2":e=i.set("cmi.core.exit","logout");break;case"2004":e=i.set("cmi.exit","normal")}if(e=i.save()){switch(i.version){case"1.2":e=r(c.LMSFinish(""));break;case"2004":e=r(c.Terminate(""))}e?i.connection.isActive=!1:(p=a.getCode(),s(o+"failed. \nError code: "+p+" \nError info: "+a.getInfo(p)))}}else s(o+"failed: API is null.")}else s(o+"aborted: Connection already terminated.");return e},pipwerks.SCORM.data.get=function(e){var i=null,t=pipwerks.SCORM,n=pipwerks.UTILS.trace,s=t.debug,r="SCORM.data.get("+e+") ";if(t.connection.isActive){var a=t.API.getHandle(),o=0;if(a){switch(t.version){case"1.2":i=a.LMSGetValue(e);break;case"2004":i=a.GetValue(e)}
    if(o=s.getCode(),""!==i||0===o)switch(e){case"cmi.core.lesson_status":case"cmi.completion_status":t.data.completionStatus=i;break;case"cmi.core.exit":case"cmi.exit":t.data.exitStatus=i}else n(r+"failed. \nError code: "+o+"\nError info: "+s.getInfo(o))}else n(r+"failed: API is null.")}else n(r+"failed: API connection is inactive.");return n(r+" value: "+i),String(i)},pipwerks.SCORM.data.set=function(e,i){var t=!1,n=pipwerks.SCORM,s=pipwerks.UTILS.trace,r=pipwerks.UTILS.StringToBoolean,a=n.debug,o="SCORM.data.set("+e+") ";if(n.connection.isActive){var c=n.API.getHandle(),p=0;if(c){switch(n.version){case"1.2":t=r(c.LMSSetValue(e,i));break;case"2004":t=r(c.SetValue(e,i))}t?("cmi.core.lesson_status"===e||"cmi.completion_status"===e)&&(n.data.completionStatus=i):(p=a.getCode(),s(o+"failed. \nError code: "+p+". \nError info: "+a.getInfo(p)))}else s(o+"failed: API is null.")}else s(o+"failed: API connection is inactive.");return t},pipwerks.SCORM.data.save=function(){var e=!1,i=pipwerks.SCORM,t=pipwerks.UTILS.trace,n=pipwerks.UTILS.StringToBoolean,s="SCORM.data.save failed";if(i.connection.isActive){var r=i.API.getHandle();
        if(r)switch(i.version){case"1.2":e=n(r.LMSCommit(""));break;case"2004":e=n(r.Commit(""))}else t(s+": API is null.")}else t(s+": API connection is inactive.");return e},pipwerks.SCORM.status=function(e,i){var t=!1,n=pipwerks.SCORM,s=pipwerks.UTILS.trace,r="SCORM.getStatus failed",a="";if(null!==e){switch(n.version){case"1.2":a="cmi.core.lesson_status";break;case"2004":a="cmi.completion_status"}switch(e){case"get":t=n.data.get(a);break;case"set":null!==i?t=n.data.set(a,i):(t=!1,s(r+": status was not specified."));break;default:t=!1,s(r+": no valid action was specified.")}}else s(r+": action was not specified.");return t},pipwerks.SCORM.debug.getCode=function(){var e=pipwerks.SCORM,i=e.API.getHandle(),t=pipwerks.UTILS.trace,n=0;if(i)switch(e.version){case"1.2":n=parseInt(i.LMSGetLastError(),10);break;case"2004":n=parseInt(i.GetLastError(),10)}else t("SCORM.debug.getCode failed: API is null.");return n},pipwerks.SCORM.debug.getInfo=function(e){var i=pipwerks.SCORM,t=i.API.getHandle(),n=pipwerks.UTILS.trace,s="";if(t)switch(i.version){case"1.2":s=t.LMSGetErrorString(e.toString());break;case"2004":s=t.GetErrorString(e.toString())}
        else n("SCORM.debug.getInfo failed: API is null.");return String(s)},pipwerks.SCORM.debug.getDiagnosticInfo=function(e){var i=pipwerks.SCORM,t=i.API.getHandle(),n=pipwerks.UTILS.trace,s="";if(t)switch(i.version){case"1.2":s=t.LMSGetDiagnostic(e);break;case"2004":s=t.GetDiagnostic(e)}else n("SCORM.debug.getDiagnosticInfo failed: API is null.");return String(s)},pipwerks.SCORM.init=pipwerks.SCORM.connection.initialize,pipwerks.SCORM.get=pipwerks.SCORM.data.get,pipwerks.SCORM.set=pipwerks.SCORM.data.set,pipwerks.SCORM.save=pipwerks.SCORM.data.save,pipwerks.SCORM.quit=pipwerks.SCORM.connection.terminate,pipwerks.UTILS.StringToBoolean=function(e){var i=typeof e;switch(i){case"object":case"string":return/(true|1)/i.test(e);case"number":return!!e;case"boolean":return e;case"undefined":return null;default:return!1}},pipwerks.UTILS.trace=function(e){pipwerks.debug.isActive&&window.console&&window.console.log&&window.console.log(e)};

// ==============================================================================================================================
/**
 * Template for integration with Tumult Hype and SCORM 1.2
 *
 * @author Antonio ElPepe Segoviano. aunsoyjoven {at} hotmail.com
 * @modified Mauricio Aguilar & Salvador ...
 *
 * @todo Rearrage into method of instanceable object
 */

/**
 * Flag used for dynamic loaded scripts (see scripts.js)
 * @type {Boolean} Global scope
 * @todo Remove variable
 */
var scripted = false;

/**
 * The HYPE object container (see scripts.js)
 * @type {Object} Global scope
 * @todo Arrange within general utilities scope
 */
var $hype;

/**
 * The pipwerks.SCORM instance for shortcut
 * @type {Object} Global scope
 * @todo Arrange within SCORM utilities scope
 */
var scorm;

/**
 * Flag for SCORM connections
 * @type {Boolean} Global scope
 * @todo Arrange within SCORM utilities scope
 */
var lmsConnected

/**
 * Data collection for LMS storage.
 * @type {Object} Global scope
 * @todo Arrange within SCORM utilities scope
 */
var SCOCollection = {}

/**
 * Flag for the data collection.
 * @type {Boolean} Global scope
 * @todo Arrange within SCOCollection scope
 */
var isSCOCollectionModified = true;

/**
 * Document to render
 * @type {String} Global scope
 * @todo Remove variable and steps to render new document
 */
var PAGE = "";

// START
// HANDLING LOAD AND UNLOAD
$(window).load(function() {
    console.log("Entrando a window load");
    scorm = pipwerks.SCORM;  //Shortcut
    //$hype = HYPE.documents[getCurrentDocument()];//JCMV AGUAS
    lmsConnected = false;
    initSCORM();
});
$(window).on('beforeunload', function() {
    console.log("Entrando a beforeunload");
    exitSco();
});

// ·········································································· //
// ···························· SCORM UTILITIES ····························· //
// ·········································································· //
/** APROBADO POR JCMV LIMPIEZA DE CODIGO 24/11/2017
 * Method for initializing the template 
 * @return {Void}
 */
var initSCORM = function () {
    lmsConnected = scorm.init();    // set the flag to the LMS status
    //lmsConnected = true;

    if(lmsConnected) {              // connected to LMS
        var completionstatus = scorm.get("cmi.core.lesson_status");// get the current course status for the user

        // the learner can access the course whenever he wants
        if(completionstatus !== "incomplete" && completionstatus !== "completed") {
            scorm.set("cmi.core.lesson_status", "incomplete");
            scorm.save();
        }

        returnToLocationSCO(completionstatus);      // ask the learner to continue where he left
    } else {
        handleError("Error: El curso no se pudo conectar con la plataforma LMS.");
    }
};

/** APROBADO POR JCMV LIMPIEZA DE CODIGO 24/11/2017
 * CRUD Methods for learner data. 
 * Read all or specified data name in cmi.suspend_data. JSON is the format of data.
 * @param  {String} dataName Optional param name to be retrieved
 * @return {Object}          Retrieved object from cmi.suspend_data
 */
var getScoData = function(dataName) {
    // connected to LMS
    if(lmsConnected) {
        // if collection has been modified
        // retrieve data from LMS
        if(isSCOCollectionModified) {
            //console.log("Pagina " +  $hype.currentSceneName());
            var lessonLocation = $hype.currentSceneName();
            var lessonLocStat = scorm.set("cmi.core.lesson_location", lessonLocation);
            //var fakeCalif = scorm.set("cmi.core.score.raw", 66);
            //console.log("inserte lesson? " + lessonLocStat);
            //console.log("inserte calif? " + fakeCalif);
           // console.log("inserte suspend? " + retorno);

            //SCOCollection = testJson;
        }
    }
    // if dataName defined, retrieve specified data
    return dataName ? SCOCollection[dataName] : SCOCollection;
};

/** APROBADO POR JCMV LIMPIEZA DE CODIGO 24/11/2017
 * CRUD Methods for learner data. 
 * Create or Update all or specified data name in cmi.suspend_data. JSON is the format of data.
 * @param  {Object} object JSON format for storage of data
 * @param  {Boolean} no_save If true, prevents commit to LMS
 * @return {Boolean}        If commit on LMS or if set on cmi.suspend_data successful
 */
var setScoData = function(object, no_save) {
    if(lmsConnected) {                                  // connected to LMS
        var sco_data = getScoData();                    // get all suspend_data of learner from LMS
            //jQuery.extend(sco_data, object);            // merge new data

        var json = JSON.stringify(sco_data);            // format to JSON

        if(json.length <= 4096) {                       // 4096 is the max string length in accordance to run time reference
            scorm.set("cmi.suspend_data", json);        // save new data

            if(no_save) return true;                    // prevents commit to LMS if especified

            isSCOCollectionModified = true;             // set collection to read from LMS
            return scorm.save();                        // commit data on LMS
        } else {
            throw "setScoData Error: Cannot save current data, it exceeds 4096 SPM char. Current data length is: " + json.length;
        }
    }
};

/** APROBADO POR JCMV LIMPIEZA DE CODIGO 24/11/2017
 * Prevents access to course if error with LMS 
 * @param  {String} msg Message to display
 * @return {void}
 */
var handleError = function (msg) {
   alert(msg);
   window.close();
};

/** APROBADO POR JCMV LIMPIEZA DE CODIGO 24/11/2017
 * Store data on cmi.core.lesson_location.
 * @param  {String} data Stringified JSON with given location
 * @return {Boolean}     If commit on LMS successful
 * @todo Handle commit over exitSCO for better performance
 */
var setLocationSCO = function(data) {
    if(lmsConnected) {                                  // connected to LMS
        scorm.set("cmi.core.lesson_location", data);    // save new data
        return scorm.save();                            // commit data on LMS
    }
};

/** APROBADO POR JCMV LIMPIEZA DE CODIGO 24/11/2017
 * Returns JSON with saved lesson location
 * @return {Object}     Last lesson location
 * @todo Implement a cache version of the lesson location for better performance
 */
var getLastLocationSCO = function() {
    // http://stackoverflow.com/questions/9158665/json-parse-fails-in-google-chrome
    return lmsConnected ? scorm.get("cmi.core.lesson_location") : null;
};

/**
 * Disconnect from LMS
 * @return {Void}
 */
var exitSco = function() {
    setScoData();
    console.log("Exit SCO");
    scorm.quit();
};

// ·········································································· //
// ·························· GENERAL UTILITIES ····························· //
// ·········································································· //
/**
 * Method to set the next file to render. It prevents direct access to PAGE property
 * @param  {String} document Name of the html file to render. Need to be formed with an "S" and the number file.
 * @return {String}          Returns the setted file name.
 */
var setNewDocument = function(document) {
    PAGE = document;
    return PAGE;
};

/**
 * Method to get the current rendered file. It prevents direct access to PAGE property
 * @return {String} Current rendered file
 */
var getCurrentDocument = function() {
    return PAGE;
};

/**
 * Method to render the given document index
 * @param  {Number} index Number in the html file name to render
 * @return {Void}
 */
var renderDocument = function(index) {
    //$hype = null;       // reset $hype object
    scripted = false;   // reset scripted flag
    $("body").empty();  // empty the html body
    //showLoader();       // present loader

    // form the uri for the render
    //var uri = "S" + index + ".hyperesources/s" + index + "_hype_generated_script.js";
    // render the html file into an iframe
    var $iframe = $(document.createElement("iframe"))
                    .prop("src", "S" + index + ".html")
                    .appendTo("body");
    
    //JCMV Obtenemos la hora en minutos de cuando se inicio el curso
    var f=new Date();
    var objFecha = new Date().getTime();
    $.cookie('objeto', objFecha);
    var cad=f.getHours()+":"+f.getMinutes();
};

/**
 * Get the name of the current rendered html file
 * @param  {Boolean} obj If specified, will return JSON format data
 * @return {String|Object}     Return stringified JSON or JSON format
 */
var getCurrentLocation = function(obj) {
    // Create new data
    var data = {
        sequence : getCurrentDocument() // get current rendered html file
    };
    // If specified, will return JSON format data
    if(obj)
        return data;
    // Return Return stringified JSON data
    return JSON.stringify(data);
};

/** APROBADO POR JCMV LIMPIEZA DE CODIGO 24/11/2017 
 * Presentation method for showing loader
 * @return {Void}
 */
var showLoader = function() {
    // verify if preloader element exists or create it
    if(!$("#preloader").length)
        $("body").prepend("<div id='preloader'><div id='status'>&nbsp;</div></div>");
    //show preloader
    $("#preloader").fadeIn();
    $("#status").fadeIn();
};

/** APROBADO POR JCMV LIMPIEZA DE CODIGO 24/11/2017
 * Presentation method for hiding loader
 * @return {Void}
 */
var hideLoader = function() {
    $("#status").fadeOut(); // will first fade out the loading animation
    $("#preloader").fadeOut("slow"); // will fade out the white DIV that covers the website.
};

/**
 * Method that displays to learner the option to continue where he left or to start again
 * @param  {String} completionstatus Course status from LMS
 * @return {Void}
 */
var returnToLocationSCO = function(completionstatus) {
    var last_location = getLastLocationSCO();                                              // get the last location with S0 as default
    //console.log("ultima ubicacion del curso " + last_location);
    //last_location = Number(last_location.sequence.replace("S",""));                 // format last location as number

    setNewDocument("S1");                           // store default location on memory
    renderDocument(1);
    
    // if learner haven't accessed the course, propably there's an empty completion status
    // and if learner last location is bigger than the current location
    if( completionstatus != "" && completionstatus != "null" && last_location) {
        // ask learner to continue
        setTimeout(function(){
            if(confirm("¿Deseas retomar el curso desde el tema que dejaste pendiente?")) {   
                $hype.showSceneNamed(last_location);
                //$hype.showSceneNamed("InstNav");
            return;
            }
        }, 1500); 
    }
};

/**
 * Save learner progress
 * @return {Void}
 */
var saveLocation = function() {
    var current_location = Number(getCurrentLocation(true).sequence.replace("S",""));   // get the current location
    var last_location = getLastLocationSCO() || {sequence: "S1"};                       // get the last location
        last_location = Number(last_location.sequence.replace("S",""));                 // format last location as number

    if(last_location <= current_location) {         // Current location is bigger than saved location
        setLocationSCO(getCurrentLocation());       // Save new last location
    }
};

/**
 * Utility for number valitation
 * @param  {Mixed}  n Mixed to validate as number
 * @return {Boolean}   Returns true if number
 */
function isNumeric(n) { return !isNaN(parseFloat(n)) && isFinite(n); }
